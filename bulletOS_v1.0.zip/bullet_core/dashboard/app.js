// Bullet-Core Training Dashboard - Interactive Logic

// Training state
let trainingState = {
    isTraining: false,
    currentEpoch: 0,
    maxEpochs: 100,
    trainLosses: [],
    valLosses: [],
    learningRates: [],
    startTime: null
};

// Configuration state
let trainingConfig = {
    data: {
        trainFile: null,
        valFile: null
    },
    model: {
        inputDim: 128,
        hiddenDim: 256,
        outputDim: 64,
        numLayers: 3
    },
    optimizer: {
        type: 'adamw',
        learningRate: 0.001,
        weightDecay: 0.01
    },
    training: {
        maxEpochs: 100,
        batchSize: 32,
        gradientClip: 1.0,
        earlyStopPatience: 10
    },
    scheduler: {
        type: 'warmup_cosine',
        warmupSteps: 100
    },
    device: {
        useGPU: true
    }
};

// Chart instances
let lossChart = null;
let lrChart = null;

// Initialize dashboard
document.addEventListener('DOMContentLoaded', () => {
    initCharts();
    setupEventListeners();
    connectToBackend();
    addLog('Dashboard initialized successfully');
});

// Initialize Charts
function initCharts() {
    const chartConfig = {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                labels: {
                    color: '#e2e8f0',
                    font: { size: 12 }
                }
            }
        },
        scales: {
            x: {
                grid: { color: 'rgba(99, 102, 241, 0.1)' },
                ticks: { color: '#94a3b8' }
            },
            y: {
                grid: { color: 'rgba(99, 102, 241, 0.1)' },
                ticks: { color: '#94a3b8' }
            }
        }
    };

    // Loss Chart
    const lossCtx = document.getElementById('lossChart').getContext('2d');
    lossChart = new Chart(lossCtx, {
        type: 'line',
        data: {
            labels: [],
            datasets: [
                {
                    label: 'Train Loss',
                    data: [],
                    borderColor: '#6366f1',
                    backgroundColor: 'rgba(99, 102, 241, 0.1)',
                    tension: 0.4,
                    fill: true
                },
                {
                    label: 'Val Loss',
                    data: [],
                    borderColor: '#8b5cf6',
                    backgroundColor: 'rgba(139, 92, 246, 0.1)',
                    tension: 0.4,
                    fill: true
                }
            ]
        },
        options: chartConfig
    });

    // Learning Rate Chart
    const lrCtx = document.getElementById('lrChart').getContext('2d');
    lrChart = new Chart(lrCtx, {
        type: 'line',
        data: {
            labels: [],
            datasets: [{
                label: 'Learning Rate',
                data: [],
                borderColor: '#10b981',
                backgroundColor: 'rgba(16, 185, 129, 0.1)',
                tension: 0.4,
                fill: true
            }]
        },
        options: chartConfig
    });
}

// Setup Event Listeners
function setupEventListeners() {
    // Training controls
    document.getElementById('startBtn').addEventListener('click', startTraining);
    document.getElementById('pauseBtn').addEventListener('click', pauseTraining);
    document.getElementById('stopBtn').addEventListener('click', stopTraining);
    document.getElementById('saveConfigBtn').addEventListener('click', saveConfiguration);

    // File uploads
    document.getElementById('trainData').addEventListener('change', handleTrainDataUpload);
    document.getElementById('valData').addEventListener('change', handleValDataUpload);

    // File upload labels
    document.querySelector('label[for="trainData"]').addEventListener('click', () => {
        document.getElementById('trainData').click();
    });
    document.querySelector('label[for="valData"]').addEventListener('click', () => {
        document.getElementById('valData').click();
    });

    // Configuration inputs
    document.getElementById('inputDim').addEventListener('change', updateConfig);
    document.getElementById('hiddenDim').addEventListener('change', updateConfig);
    document.getElementById('outputDim').addEventListener('change', updateConfig);
    document.getElementById('numLayers').addEventListener('change', updateConfig);
    document.getElementById('optimizerType').addEventListener('change', updateConfig);
    document.getElementById('learningRate').addEventListener('change', updateConfig);
    document.getElementById('weightDecay').addEventListener('change', updateConfig);
    document.getElementById('maxEpochs').addEventListener('change', updateConfig);
    document.getElementById('batchSize').addEventListener('change', updateConfig);
    document.getElementById('gradClip').addEventListener('change', updateConfig);
    document.getElementById('earlyStop').addEventListener('change', updateConfig);
    document.getElementById('schedulerType').addEventListener('change', updateConfig);
    document.getElementById('warmupSteps').addEventListener('change', updateConfig);
    document.getElementById('useGPU').addEventListener('change', updateConfig);
}

// Handle file uploads
function handleTrainDataUpload(event) {
    const file = event.target.files[0];
    if (file) {
        trainingConfig.data.trainFile = file;
        document.getElementById('trainFileName').textContent = file.name;
        addLog(`Training data loaded: ${file.name}`);
        uploadFile(file, 'train');
    }
}

function handleValDataUpload(event) {
    const file = event.target.files[0];
    if (file) {
        trainingConfig.data.valFile = file;
        document.getElementById('valFileName').textContent = file.name;
        addLog(`Validation data loaded: ${file.name}`);
        uploadFile(file, 'val');
    }
}

// Upload file to backend
async function uploadFile(file, type) {
    const formData = new FormData();
    formData.append('file', file);
    formData.append('type', type);

    try {
        const response = await fetch('http://localhost:5000/api/data/upload', {
            method: 'POST',
            body: formData
        });

        const result = await response.json();
        addLog(`${type === 'train' ? 'Training' : 'Validation'} data uploaded successfully`);
    } catch (e) {
        addLog(`Failed to upload ${type} data: ${e.message}`, 'error');
    }
}

// Update configuration from inputs
function updateConfig() {
    trainingConfig.model.inputDim = parseInt(document.getElementById('inputDim').value);
    trainingConfig.model.hiddenDim = parseInt(document.getElementById('hiddenDim').value);
    trainingConfig.model.outputDim = parseInt(document.getElementById('outputDim').value);
    trainingConfig.model.numLayers = parseInt(document.getElementById('numLayers').value);
    trainingConfig.optimizer.type = document.getElementById('optimizerType').value;
    trainingConfig.optimizer.learningRate = parseFloat(document.getElementById('learningRate').value);
    trainingConfig.optimizer.weightDecay = parseFloat(document.getElementById('weightDecay').value);
    trainingConfig.training.maxEpochs = parseInt(document.getElementById('maxEpochs').value);
    trainingConfig.training.batchSize = parseInt(document.getElementById('batchSize').value);
    trainingConfig.training.gradientClip = parseFloat(document.getElementById('gradClip').value);
    trainingConfig.training.earlyStopPatience = parseInt(document.getElementById('earlyStop').value);
    trainingConfig.scheduler.type = document.getElementById('schedulerType').value;
    trainingConfig.scheduler.warmupSteps = parseInt(document.getElementById('warmupSteps').value);
    trainingConfig.device.useGPU = document.getElementById('useGPU').checked;

    trainingState.maxEpochs = trainingConfig.training.maxEpochs;
}

// Save configuration
function saveConfiguration() {
    const configJson = JSON.stringify(trainingConfig, null, 2);
    const blob = new Blob([configJson], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'training_config.json';
    a.click();
    URL.revokeObjectURL(url);
    addLog('Configuration saved to training_config.json');
}

// Connect to Backend (WebSocket or HTTP polling)
function connectToBackend() {
    // Try WebSocket connection
    try {
        const ws = new WebSocket('ws://localhost:8765');

        ws.onopen = () => {
            addLog('Connected to training backend');
            updateStatus('Connected', 'success');
        };

        ws.onmessage = (event) => {
            const data = JSON.parse(event.data);
            handleTrainingUpdate(data);
        };

        ws.onerror = () => {
            addLog('WebSocket connection failed, using HTTP polling', 'warning');
            startHttpPolling();
        };
    } catch (e) {
        addLog('Starting in demo mode', 'info');
        startDemoMode();
    }
}

// HTTP Polling fallback
function startHttpPolling() {
    setInterval(async () => {
        try {
            const response = await fetch('http://localhost:5000/api/training/status');
            const data = await response.json();
            handleTrainingUpdate(data);
        } catch (e) {
            // Backend not available
        }
    }, 1000);
}

// Handle Training Updates
function handleTrainingUpdate(data) {
    if (data.epoch !== undefined) {
        trainingState.currentEpoch = data.epoch;
        updateMetric('epochValue', `${data.epoch} / ${trainingState.maxEpochs}`);
    }

    if (data.train_loss !== undefined) {
        trainingState.trainLosses.push(data.train_loss);
        updateMetric('trainLossValue', data.train_loss.toFixed(4));
        updateChart(lossChart, 0, data.train_loss);
    }

    if (data.val_loss !== undefined) {
        trainingState.valLosses.push(data.val_loss);
        updateMetric('valLossValue', data.val_loss.toFixed(4));
        updateChart(lossChart, 1, data.val_loss);
    }

    if (data.learning_rate !== undefined) {
        trainingState.learningRates.push(data.learning_rate);
        updateMetric('lrValue', data.learning_rate.toExponential(2));
        updateLRChart(data.learning_rate);
    }

    if (data.time_per_epoch !== undefined) {
        updateMetric('timeValue', `${data.time_per_epoch.toFixed(2)}s`);
        updateETA(data.time_per_epoch);
    }

    if (data.vram_usage !== undefined) {
        updateVRAM(data.vram_usage, data.vram_total || 2048);
    }

    if (data.message) {
        addLog(data.message);
    }
}

// Start Training
async function startTraining() {
    // Update config from inputs
    updateConfig();

    trainingState.isTraining = true;
    trainingState.startTime = Date.now();
    trainingState.currentEpoch = 0;
    trainingState.trainLosses = [];
    trainingState.valLosses = [];
    trainingState.learningRates = [];

    // Clear charts
    lossChart.data.labels = [];
    lossChart.data.datasets[0].data = [];
    lossChart.data.datasets[1].data = [];
    lossChart.update();

    lrChart.data.labels = [];
    lrChart.data.datasets[0].data = [];
    lrChart.update();

    updateStatus('Training', 'training');
    document.getElementById('startBtn').disabled = true;
    document.getElementById('pauseBtn').disabled = false;
    document.getElementById('stopBtn').disabled = false;

    addLog('Training started with configuration:');
    addLog(`  Model: ${trainingConfig.model.inputDim} → ${trainingConfig.model.hiddenDim} → ${trainingConfig.model.outputDim}`);
    addLog(`  Optimizer: ${trainingConfig.optimizer.type.toUpperCase()} (lr=${trainingConfig.optimizer.learningRate})`);
    addLog(`  Epochs: ${trainingConfig.training.maxEpochs}, Batch: ${trainingConfig.training.batchSize}`);

    // Send start command to backend with full config
    try {
        const response = await fetch('http://localhost:5000/api/training/start', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(trainingConfig)
        });

        if (!response.ok) {
            throw new Error('Backend error');
        }
    } catch (e) {
        addLog('Backend not connected, running demo mode', 'warning');
        runDemoTraining();
    }
}

// Pause Training
function pauseTraining() {
    trainingState.isTraining = false;
    updateStatus('Paused', 'warning');
    addLog('Training paused');

    document.getElementById('pauseBtn').disabled = true;
    document.getElementById('startBtn').disabled = false;
}

// Stop Training
function stopTraining() {
    trainingState.isTraining = false;
    updateStatus('Stopped', 'danger');
    addLog('Training stopped');

    document.getElementById('stopBtn').disabled = true;
    document.getElementById('pauseBtn').disabled = true;
    document.getElementById('startBtn').disabled = false;
}

// Update Metric
function updateMetric(id, value) {
    document.getElementById(id).textContent = value;
}

// Update Chart
function updateChart(chart, datasetIndex, value) {
    const epoch = trainingState.currentEpoch;

    if (!chart.data.labels.includes(epoch)) {
        chart.data.labels.push(epoch);
    }

    chart.data.datasets[datasetIndex].data.push(value);

    // Keep last 50 points
    if (chart.data.labels.length > 50) {
        chart.data.labels.shift();
        chart.data.datasets.forEach(dataset => dataset.data.shift());
    }

    chart.update('none');
}

// Update LR Chart
function updateLRChart(lr) {
    const epoch = trainingState.currentEpoch;

    if (!lrChart.data.labels.includes(epoch)) {
        lrChart.data.labels.push(epoch);
    }

    lrChart.data.datasets[0].data.push(lr);

    if (lrChart.data.labels.length > 50) {
        lrChart.data.labels.shift();
        lrChart.data.datasets[0].data.shift();
    }

    lrChart.update('none');
}

// Update VRAM
function updateVRAM(used, total) {
    const percentage = (used / total) * 100;
    document.getElementById('vramUsage').textContent = `${used} MB / ${total} MB`;
    document.getElementById('vramProgress').style.width = `${percentage}%`;
}

// Update ETA
function updateETA(timePerEpoch) {
    const remainingEpochs = trainingState.maxEpochs - trainingState.currentEpoch;
    const etaSeconds = remainingEpochs * timePerEpoch;

    const hours = Math.floor(etaSeconds / 3600);
    const minutes = Math.floor((etaSeconds % 3600) / 60);
    const seconds = Math.floor(etaSeconds % 60);

    const eta = `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    updateMetric('etaValue', eta);
}

// Update Status Badge
function updateStatus(text, type) {
    const badge = document.getElementById('statusBadge');
    const dot = badge.querySelector('.status-dot');

    badge.querySelector('span:last-child').textContent = text;

    const colors = {
        success: '#10b981',
        training: '#6366f1',
        warning: '#f59e0b',
        danger: '#ef4444'
    };

    dot.style.background = colors[type] || colors.success;
}

// Add Log Entry
function addLog(message, type = 'info') {
    const container = document.getElementById('logContainer');
    const entry = document.createElement('div');
    entry.className = 'log-entry';

    const time = new Date().toLocaleTimeString();
    const icon = type === 'warning' ? '⚠️' : type === 'error' ? '❌' : '✅';

    entry.innerHTML = `
        <span class="log-time">${time}</span>
        <span class="log-message">${icon} ${message}</span>
    `;

    container.appendChild(entry);
    container.scrollTop = container.scrollHeight;

    // Keep last 100 entries
    while (container.children.length > 100) {
        container.removeChild(container.firstChild);
    }
}

// Demo Mode (for testing without backend)
function runDemoTraining() {
    let epoch = 0;
    const demoInterval = setInterval(() => {
        if (!trainingState.isTraining || epoch >= trainingState.maxEpochs) {
            clearInterval(demoInterval);
            return;
        }

        epoch++;
        const trainLoss = 1.0 * Math.exp(-epoch / 20) + Math.random() * 0.05;
        const valLoss = trainLoss + Math.random() * 0.1;
        const lr = 0.001 * (1 - epoch / trainingState.maxEpochs);

        handleTrainingUpdate({
            epoch,
            train_loss: trainLoss,
            val_loss: valLoss,
            learning_rate: lr,
            time_per_epoch: 2.5 + Math.random(),
            vram_usage: 800 + Math.random() * 200,
            message: `Epoch ${epoch} complete`
        });
    }, 1000);
}

function startDemoMode() {
    addLog('Running in demo mode - click Start to see simulated training');
}
