const API_URL = 'http://localhost:8000';

// ===== PRODUCTION DASHBOARD: CHARTS & METRICS =====
let lossChart, lrChart, perplexityChart;
let trainingStartTime = null;
let lastStepTime = null;

// Chart data storage
const chartData = {
    steps: [],
    trainLoss: [],
    valLoss: [],
    learningRate: [],
    perplexity: []
};

// Preset configurations
function loadQuickPreset() {
    // Super-fast config from fiixspeed.txt (8-10x faster)
    trainForm.vocab_size.value = 2000;  // Reduced from 5000
    trainForm.dim.value = 128;  // 4x faster than 256
    trainForm.num_heads.value = 4;
    trainForm.num_layers.value = 4;  // 2x faster than 8
    trainForm.max_seq_len.value = 64;
    trainForm.learning_rate.value = 0.001;
    trainForm.epochs.value = 1;
    trainForm.batch_size.value = 4;
    log('Loaded Super-Fast preset (128 dim, 4 layers) - 8x faster!', 'info');
}

function loadFullPreset() {
    // BULLET_SPEC_v1.0.md configuration
    trainForm.vocab_size.value = 5000;
    trainForm.dim.value = 256;  // hidden_size from spec
    trainForm.num_heads.value = 4;  // num_heads from spec
    trainForm.num_layers.value = 8;  // num_layers from spec
    trainForm.max_seq_len.value = 64;
    trainForm.learning_rate.value = 0.001;
    trainForm.epochs.value = 2;  // Reduced from 5 for reasonable training time
    trainForm.batch_size.value = 8;
    log('Loaded BULLET_SPEC_v1.0 configuration', 'info');
}

function loadProductionPreset() {
    // Advanced Production Config (from improvementsconfig.txt)
    trainForm.vocab_size.value = 4000;
    trainForm.dim.value = 256;
    trainForm.num_heads.value = 4;
    trainForm.num_layers.value = 8;
    trainForm.max_seq_len.value = 128; // Longer context
    trainForm.learning_rate.value = 0.0005; // 5e-4
    trainForm.epochs.value = 3;
    trainForm.batch_size.value = 8; // Effective batch 64 via grad accum
    log('Loaded Production Config (Best Quality)', 'info');
}

const trainForm = document.getElementById('trainForm');
const trainBtn = document.getElementById('trainBtn');
const stopBtn = document.getElementById('stopBtn');
const logConsole = document.getElementById('logConsole');
const progressBar = document.getElementById('progressBar');
const progressPercent = document.getElementById('progressPercent');
const downloadArea = document.getElementById('downloadArea');
const downloadLink = document.getElementById('downloadLink');
const clearLogsBtn = document.getElementById('clearLogs');

// Stats elements
const hardwareInfo = document.getElementById('hardwareInfo');
const currentEpoch = document.getElementById('currentEpoch');
const currentBatch = document.getElementById('currentBatch');
const avgLoss = document.getElementById('avgLoss');
const timeElapsed = document.getElementById('timeElapsed');

// New metrics elements
const currentLossEl = document.getElementById('currentLoss');
const bestValLossEl = document.getElementById('bestValLoss');
const etaEl = document.getElementById('eta');
const tokensPerSecEl = document.getElementById('tokensPerSec');

let pollInterval = null;
let startTime = null;
let timerInterval = null;

function log(message, type = 'normal') {
    const entry = document.createElement('div');
    entry.className = 'log-entry';

    if (type === 'error') entry.classList.add('log-error');
    else if (type === 'success') entry.classList.add('log-success');
    else if (type === 'info') entry.classList.add('log-info');

    const timestamp = new Date().toLocaleTimeString();
    entry.textContent = `[${timestamp}] ${message}`;
    logConsole.appendChild(entry);
    logConsole.scrollTop = logConsole.scrollHeight;
}

function parseLogForStats(logMsg) {
    // Parse "Epoch X | Batch Y/Z | Loss: W"
    const epochMatch = logMsg.match(/Epoch (\d+)/);
    const batchMatch = logMsg.match(/Batch (\d+)\/(\d+)/);
    const lossMatch = logMsg.match(/Loss: ([\d.]+)/);
    const avgLossMatch = logMsg.match(/Avg Loss: ([\d.]+)/);

    // Hardware detection
    const hardwareMatch = logMsg.match(/Using (CPU|GPU)/);
    const threadsMatch = logMsg.match(/(\d+) threads/);
    const mklMatch = logMsg.match(/(with|without) MKL/);
    const dtypeMatch = logMsg.match(/dtype: (\w+)/);

    // Config detection
    const configMatch = logMsg.match(/Training started with config: (.+)/);

    if (epochMatch) {
        const epochNum = epochMatch[1];
        const totalEpochs = trainForm.epochs.value;
        currentEpoch.textContent = `${epochNum}/${totalEpochs}`;
    }

    if (batchMatch) {
        currentBatch.textContent = `${batchMatch[1]}/${batchMatch[2]}`;
    }

    if (lossMatch) {
        const loss = parseFloat(lossMatch[1]);
        currentLoss.textContent = loss.toFixed(4);
        currentLoss.style.color = loss < 10 ? 'var(--accent-green)' : loss < 30 ? 'var(--accent-yellow)' : 'var(--accent-red)';
    }

    if (avgLossMatch) {
        avgLoss.textContent = parseFloat(avgLossMatch[1]).toFixed(4);
    }

    if (hardwareMatch) {
        let hw = hardwareMatch[1];
        const threads = threadsMatch ? ` (${threadsMatch[1]} threads)` : '';
        const mkl = mklMatch ? ` ${mklMatch[1]} MKL` : '';
        hardwareInfo.textContent = hw + threads + mkl;
        hardwareInfo.style.color = hw === 'GPU' ? 'var(--accent-green)' : 'var(--accent-blue)';
    }

    if (dtypeMatch) {
        const currentHW = hardwareInfo.textContent;
        if (!currentHW.includes(dtypeMatch[1])) {
            hardwareInfo.textContent = currentHW + ` [${dtypeMatch[1]}]`;
        }
    }

    if (configMatch) {
        try {
            const config = JSON.parse(configMatch[1]);
            currentEpoch.textContent = `0/${config.epochs}`;
        } catch (e) { }
    }
}

function updateTimer() {
    if (startTime) {
        const elapsed = Math.floor((Date.now() - startTime) / 1000);
        const mins = Math.floor(elapsed / 60);
        const secs = elapsed % 60;
        timeElapsed.textContent = `${mins}m ${secs}s`;
    }
}

async function startTraining(event) {
    event.preventDefault();

    trainBtn.disabled = true;
    trainBtn.classList.add('hidden');
    stopBtn.classList.remove('hidden');

    logConsole.innerHTML = '';
    downloadArea.classList.add('hidden');
    progressBar.style.width = '0%';
    progressPercent.textContent = '0%';

    // Reset stats
    currentEpoch.textContent = '0/0';
    currentBatch.textContent = '0/0';
    currentLoss.textContent = '-';
    avgLoss.textContent = '-';
    hardwareInfo.textContent = 'Detecting...';

    startTime = Date.now();
    timerInterval = setInterval(updateTimer, 1000);

    const formData = new FormData(trainForm);

    try {
        log('Uploading dataset and starting training...', 'info');
        const response = await fetch(`${API_URL}/api/train`, {
            method: 'POST',
            body: formData
        });

        if (!response.ok) {
            const err = await response.json();
            throw new Error(err.message || 'Failed to start training');
        }

        const data = await response.json();
        log(`Training started with config: ${JSON.stringify(data.config)}`, 'success');

        // Start polling logs
        if (pollInterval) clearInterval(pollInterval);
        pollInterval = setInterval(pollLogs, 500); // Poll every 500ms for real-time feel

    } catch (error) {
        log(`Error: ${error.message}`, 'error');
        resetUI();
    }
}

async function stopTraining() {
    try {
        log('Requesting stop...', 'info');
        const response = await fetch(`${API_URL}/api/stop`, { method: 'POST' });
        const data = await response.json();
        log(data.message, 'info');
    } catch (error) {
        log(`Error stopping: ${error.message}`, 'error');
    }
}

function resetUI() {
    trainBtn.disabled = false;
    trainBtn.classList.remove('hidden');
    stopBtn.classList.add('hidden');
    if (pollInterval) clearInterval(pollInterval);
    if (timerInterval) clearInterval(timerInterval);
    startTime = null;
}

async function pollLogs() {
    try {
        const response = await fetch(`${API_URL}/api/logs`);
        const data = await response.json();

        // Update logs (only append new ones)
        const currentLogCount = logConsole.children.length;
        if (data.logs.length > currentLogCount) {
            for (let i = currentLogCount; i < data.logs.length; i++) {
                log(data.logs[i]); // Log the message
                parseLogForStats(data.logs[i]); // Parse for stats
            }
        }

        // Update progress
        const pct = Math.round(data.progress * 100);
        progressBar.style.width = `${pct}%`;
        progressPercent.textContent = `${pct}%`;

        // ===== UPDATE CHARTS AND METRICS =====
        if (data.metrics) {
            updateCharts(data.metrics);
            updateMetrics(data);
        }

        // Add/remove training-active class for progress bar animation
        const container = document.querySelector('.progress-container');
        if (data.is_training) {
            container?.classList.add('training-active');
        } else {
            container?.classList.remove('training-active');
        }

        if (data.model_available) {
            resetUI();
            log('Training complete! Model ready for download.', 'success');

            downloadLink.href = `${API_URL}/download/${data.model_name}`;
            downloadArea.classList.remove('hidden');
        } else if (!data.is_training && data.progress < 1.0 && data.logs.length > 0) {
            // Stopped unexpectedly or by user
            resetUI();
            log('Training stopped.', 'info');
        }

    } catch (error) {
        console.error('Polling error:', error);
    }
}

// Event listeners
trainBtn.addEventListener('click', startTraining);
stopBtn.addEventListener('click', stopTraining);
clearLogsBtn.addEventListener('click', () => {
    logConsole.innerHTML = '';
    log('Logs cleared', 'info');
});

// ===== PRODUCTION DASHBOARD: CHART INITIALIZATION =====

function initCharts() {
    const chartOptions = {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                labels: { color: '#f1f5f9', font: { size: 11 } }
            }
        },
        scales: {
            y: {
                ticks: { color: '#cbd5e1' },
                grid: { color: '#475569' }
            },
            x: {
                ticks: { color: '#cbd5e1' },
                grid: { color: '#475569' }
            }
        },
        animation: {
            duration: 300
        }
    };

    // Loss Chart (Tricolor theme)
    lossChart = new Chart(document.getElementById('lossChart'), {
        type: 'line',
        data: {
            labels: [],
            datasets: [{
                label: 'Training Loss',
                data: [],
                borderColor: '#FF9933', // Saffron
                backgroundColor: 'rgba(255, 153, 51, 0.1)',
                tension: 0.4,
                borderWidth: 2
            }, {
                label: 'Validation Loss',
                data: [],
                borderColor: '#138808', // Green
                backgroundColor: 'rgba(19, 136, 8, 0.1)',
                tension: 0.4,
                borderWidth: 2
            }]
        },
        options: chartOptions
    });

    // Learning Rate Chart
    lrChart = new Chart(document.getElementById('lrChart'), {
        type: 'line',
        data: {
            labels: [],
            datasets: [{
                label: 'Learning Rate',
                data: [],
                borderColor: '#FFB366', // Light Saffron
                backgroundColor: 'rgba(255, 179, 102, 0.1)',
                tension: 0.4,
                borderWidth: 2
            }]
        },
        options: chartOptions
    });

    // Perplexity Chart
    perplexityChart = new Chart(document.getElementById('perplexityChart'), {
        type: 'line',
        data: {
            labels: [],
            datasets: [{
                label: 'Perplexity',
                data: [],
                borderColor: '#17A00F', // Light Green
                backgroundColor: 'rgba(23, 160, 15, 0.1)',
                tension: 0.4,
                borderWidth: 2
            }]
        },
        options: chartOptions
    });
}

function updateCharts(metrics) {
    if (!metrics || !metrics.steps || metrics.steps.length === 0) return;

    const steps = metrics.steps;
    const labels = steps.map(s => `Step ${s}`);

    // Update Loss Chart
    if (lossChart) {
        lossChart.data.labels = labels;
        lossChart.data.datasets[0].data = metrics.train_loss || [];
        lossChart.data.datasets[1].data = metrics.val_loss || [];
        lossChart.update('none'); // No animation for performance
    }

    // Update LR Chart
    if (lrChart && metrics.learning_rate) {
        lrChart.data.labels = labels;
        lrChart.data.datasets[0].data = metrics.learning_rate;
        lrChart.update('none');
    }

    // Update Perplexity Chart
    if (perplexityChart && metrics.perplexity) {
        perplexityChart.data.labels = labels;
        perplexityChart.data.datasets[0].data = metrics.perplexity;
        perplexityChart.update('none');
    }
}

function updateMetrics(data) {
    const metrics = data.metrics || {};

    // Current Loss
    if (metrics.train_loss && metrics.train_loss.length > 0) {
        const lastLoss = metrics.train_loss[metrics.train_loss.length - 1];
        currentLossEl.textContent = lastLoss.toFixed(4);
    }

    // Best Val Loss
    if (metrics.best_val_loss !== undefined && metrics.best_val_loss < 1000) {
        bestValLossEl.textContent = metrics.best_val_loss.toFixed(4);
    }

    // ETA Calculation
    if (data.is_training && data.progress > 0) {
        if (!trainingStartTime) {
            trainingStartTime = Date.now();
        }

        const elapsed = (Date.now() - trainingStartTime) / 1000; // seconds
        const totalTime = elapsed / data.progress;
        const remaining = totalTime - elapsed;

        etaEl.textContent = formatTime(remaining);
    } else if (!data.is_training) {
        etaEl.textContent = '-';
        trainingStartTime = null;
    }

    // Tokens/sec (if available)
    if (metrics.tokens_per_sec) {
        tokensPerSecEl.textContent = Math.round(metrics.tokens_per_sec);
    }
}

function formatTime(seconds) {
    if (seconds < 0 || !isFinite(seconds)) return '-';

    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = Math.floor(seconds % 60);

    if (h > 0) return `${h}h ${m}m`;
    if (m > 0) return `${m}m ${s}s`;
    return `${s}s`;
}

// Initialize charts on page load
document.addEventListener('DOMContentLoaded', () => {
    initCharts();
    log('Dashboard initialized with real-time graphs 📊', 'info');
});
